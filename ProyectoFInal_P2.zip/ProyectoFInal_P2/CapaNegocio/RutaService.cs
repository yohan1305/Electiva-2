﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class RutaService
    {
        private readonly RutaRepository _repo = new RutaRepository();

        public void Registrar(Ruta ruta)
        {
            _repo.Registrar(ruta);
        }

        public List<Ruta> Listar()
        {
            return _repo.Listar();
        }

        public void ActualizarEstado(int rutaId, bool estado)
        {
            _repo.ActualizarEstadoRuta(rutaId, estado);
        }


    }
}
