﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;


namespace CapaNegocio
{
    public class AsignacionService
    {
        private readonly AsignacionRepository _repo = new AsignacionRepository();

        public void Registrar(Asignacion asignacion)
        {
            if (asignacion == null)
                throw new ArgumentNullException(nameof(asignacion), "La asignación no puede ser nula.");

            if (asignacion.ConductorID <= 0 || asignacion.AutobusID <= 0 || asignacion.RutaID <= 0 || asignacion.UsuarioID <= 0)
                throw new ArgumentException("Todos los IDs deben ser válidos y mayores a cero.");

            _repo.Registrar(asignacion);
        }

        public List<AsignadoView> Listar()
        {
            return _repo.Listar();
        }


    }
}
