﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class ConductorService
    {
        private readonly ConductorRepository _repo = new ConductorRepository();

        public void Registrar(Conductor conductor)
        {
            _repo.Registrar(conductor);
        }

        public List<Conductor> Listar()
        {
            return _repo.Listar();
        }

        public void ActualizarEstado(int conductorId, bool estado)
        {
            _repo.ActualizarEstadoConductor(conductorId, estado);
        }

        public bool ExisteCedula(string cedula)
        {
            return _repo.ExisteCedula(cedula);
        }




    }
}
