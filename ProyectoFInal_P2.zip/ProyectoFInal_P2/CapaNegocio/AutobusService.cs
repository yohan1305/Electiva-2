﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class AutobusService
    {
        private readonly AutobusRepository _repo = new AutobusRepository();

        public void Registrar(Autobus autobus)
        {
            _repo.Registrar(autobus);
        }

        public List<Autobus> Listar()
        {
            return _repo.Listar();
        }

        public void ActualizarEstado(int autobusId, bool estado)
        {
            _repo.ActualizarEstadoAutobus(autobusId, estado);
        }



    }
}
