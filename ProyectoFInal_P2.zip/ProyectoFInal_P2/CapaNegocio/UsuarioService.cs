﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad.Usuario;

namespace CapaNegocio
{
    public class UsuarioService
    {
        private readonly UsuarioRepository _repositorio = new UsuarioRepository();

        public bool Registrar(Usuario usuario)
        {
            if (usuario == null)
                throw new ArgumentNullException(nameof(usuario), "Debe proporcionar datos de usuario.");

            // Aquí ya no encriptamos la contraseña
            return _repositorio.RegistrarUsuario(usuario);
        }



        public Usuario Login(string nombreUsuario, string clave)
        {
            return _repositorio.Login(nombreUsuario, clave);
        }
    }
}
