﻿namespace CapaPresentacion_3
{
    public class Class1
    {

    }
}
