﻿namespace CapaPresentacion2
{
    public class Class1
    {

    }
}
