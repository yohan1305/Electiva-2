﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using Microsoft.Data.SqlClient;

namespace CapaDatos
{
    public class AsignacionRepository
    {
        public void Registrar(Asignacion asignacion)
        {
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("SP_REGISTRARASIGNACION", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ConductorID", asignacion.ConductorID);
            cmd.Parameters.AddWithValue("@AutobusID", asignacion.AutobusID);
            cmd.Parameters.AddWithValue("@RutaID", asignacion.RutaID);
            cmd.Parameters.AddWithValue("@UsuarioID", asignacion.UsuarioID);

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        public List<AsignadoView> Listar()
        {
            var lista = new List<AsignadoView>();
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("SP_LISTARASIGNACIONES", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new AsignadoView
                {
                    Nombre_Conductor = reader["Nombre_Conductor"].ToString(),
                    Apellido_Conductor = reader["Apellido_Conductor"].ToString(),
                    Cedula = reader["Cedula"].ToString(),
                    Autobus_Marca = reader["Autobus_Marca"].ToString(),
                    Autobus_Modelo = reader["Autobus_Modelo"].ToString(),
                    Autobus_Placa = reader["Autobus_Placa"].ToString(),
                    Autobus_Año = Convert.ToInt32(reader["Autobus_Año"]),
                    Ruta = reader["Ruta"].ToString()
                });
            }
            return lista;
        }


    }

}
