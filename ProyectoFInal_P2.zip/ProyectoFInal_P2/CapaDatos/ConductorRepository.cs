﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using Microsoft.Data.SqlClient;

namespace CapaDatos
{
    public class ConductorRepository
    {
        // Registrar nuevo conductor
        public void Registrar(Conductor conductor)
        {
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("SP_REGISTRARCONDUCTOR", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Nombre", conductor.Nombre);
            cmd.Parameters.AddWithValue("@Apellido", conductor.Apellido);
            cmd.Parameters.AddWithValue("@FechaN", conductor.FechaN);
            cmd.Parameters.AddWithValue("@Cedula", conductor.Cedula);
            cmd.Parameters.AddWithValue("@Estado", conductor.Estado); // false = disponible

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        // Listar todos los conductores
        public List<Conductor> Listar()
        {
            var lista = new List<Conductor>();
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("SP_LISTARCONDUCTORES", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new Conductor
                {
                    ConductorID = Convert.ToInt32(reader["ID"]),
                    Codigo = reader["Codigo"].ToString(),
                    Nombre = reader["Nombre"].ToString(),
                    Apellido = reader["Apellido"].ToString(),
                    FechaN = Convert.ToDateTime(reader["FechaN"]),
                    Cedula = reader["Cedula"].ToString(),
                    Estado = Convert.ToBoolean(reader["Estado"])
                });
            }
            return lista;
        }

        // Actualizar estado de disponibilidad
        public void ActualizarEstadoConductor(int conductorId, bool estado)
        {
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("UPDATE Conductores SET Estado = @Estado WHERE ID = @ID", conn);
            cmd.Parameters.AddWithValue("@Estado", estado);
            cmd.Parameters.AddWithValue("@ID", conductorId);

            conn.Open();
            cmd.ExecuteNonQuery();
        }

        // Validar si ya existe una cédula registrada
        public bool ExisteCedula(string cedula)
        {
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("SELECT COUNT(*) FROM Conductores WHERE Cedula = @Cedula", conn);
            cmd.Parameters.AddWithValue("@Cedula", cedula);

            conn.Open();
            int count = (int)cmd.ExecuteScalar();
            return count > 0;
        }
    }
}
