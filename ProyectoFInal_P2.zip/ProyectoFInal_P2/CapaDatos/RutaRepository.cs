﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using Microsoft.Data.SqlClient;

namespace CapaDatos
{
    public class RutaRepository
    {
        public void Registrar(Ruta ruta)
        {
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("SP_REGISTRARRUTA", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Ruta", ruta.RutaNombre);
            cmd.Parameters.AddWithValue("@Estado", ruta.Estado);
            conn.Open();
            cmd.ExecuteNonQuery();
        }

        public List<Ruta> Listar()
        {
            var lista = new List<Ruta>();
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("SP_LISTARRUTAS", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new Ruta
                {
                    RutaID = Convert.ToInt32(reader["ID"]),
                    RutaNombre = reader["Ruta"].ToString(),
                    Estado = Convert.ToBoolean(reader["Estado"])
                });
            }
            return lista;
        }
        public void ActualizarEstadoRuta(int rutaId, bool estado)
        {
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("UPDATE Rutas SET Estado = @Estado WHERE ID = @ID", conn);
            cmd.Parameters.AddWithValue("@Estado", estado);
            cmd.Parameters.AddWithValue("@ID", rutaId);
            conn.Open();
            cmd.ExecuteNonQuery();
        }


    }
}
