﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using Microsoft.Data.SqlClient;

namespace CapaDatos
{
    public class AutobusRepository
    {
        public void Registrar(Autobus autobus)
        {
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("SP_REGISTRARAUTOBUS", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Marca", autobus.Marca);
            cmd.Parameters.AddWithValue("@Modelo", autobus.Modelo);
            cmd.Parameters.AddWithValue("@Placa", autobus.Placa);
            cmd.Parameters.AddWithValue("@Color", autobus.Color);
            cmd.Parameters.AddWithValue("@Año", autobus.Año);
            cmd.Parameters.AddWithValue("@Estado", autobus.Estado);
            conn.Open();
            cmd.ExecuteNonQuery();
        }

        public List<Autobus> Listar()
        {
            var lista = new List<Autobus>();
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("SP_LISTARAUTOBUSES", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new Autobus
                {
                    AutobusID = Convert.ToInt32(reader["ID"]),
                    Marca = reader["Marca"].ToString(),
                    Modelo = reader["Modelo"].ToString(),
                    Placa = reader["Placa"].ToString(),
                    Color = reader["Color"].ToString(),
                    Año = Convert.ToInt32(reader["Año"]),
                    Estado = Convert.ToBoolean(reader["Estado"])
                });
            }
            return lista;
        }

        public void ActualizarEstadoAutobus(int autobusId, bool estado)
        {
            using var conn = Conexion.ObtenerConexion();
            using var cmd = new SqlCommand("UPDATE Autobuses SET Estado = @Estado WHERE ID = @ID", conn);
            cmd.Parameters.AddWithValue("@Estado", estado);
            cmd.Parameters.AddWithValue("@ID", autobusId);
            conn.Open();
            cmd.ExecuteNonQuery();
        }

    }
}
