﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace CapaDatos
{
    public class Conexion
    {
        public static readonly string cadena = @"Data Source=localhost\SQLEXPRESS; Initial Catalog=Sistema_Autobuses; Integrated Security=True; Encrypt=False;";

        public static SqlConnection ObtenerConexion()
        {
            return new SqlConnection(cadena);
        }

    }
}
