﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaEntidad.Usuario;
using Microsoft.Data.SqlClient;

namespace CapaDatos
{
    public class UsuarioRepository
    {
        public bool RegistrarUsuario(Usuario usuario)
        {
            if (usuario == null)
                throw new ArgumentNullException(nameof(usuario), "El usuario no puede ser nulo.");

            // Validaciones básicas antes de la inserción
            if (string.IsNullOrWhiteSpace(usuario.NombreUsuario))
                throw new ArgumentException("El nombre de usuario es obligatorio.", nameof(usuario.NombreUsuario));
            if (string.IsNullOrWhiteSpace(usuario.Clave))
                throw new ArgumentException("La clave es obligatoria.", nameof(usuario.Clave));
            if (string.IsNullOrWhiteSpace(usuario.Nombre))
                throw new ArgumentException("El nombre es obligatorio.", nameof(usuario.Nombre));
            if (string.IsNullOrWhiteSpace(usuario.Apellido))
                throw new ArgumentException("El apellido es obligatorio.", nameof(usuario.Apellido));
            if (string.IsNullOrWhiteSpace(usuario.Rol))
                throw new ArgumentException("El rol es obligatorio.", nameof(usuario.Rol));

            const string sql = @"
                INSERT INTO Usuarios 
                    (NombreUsuario, Clave, Nombre, Apellido, Rol)
                VALUES 
                    (@NombreUsuario, @Clave, @Nombre, @Apellido, @Rol);
                SELECT CAST(SCOPE_IDENTITY() AS INT);
            ";

            try
            {
                using (SqlConnection conn = Conexion.ObtenerConexion())
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add("@NombreUsuario", SqlDbType.NVarChar, 50).Value = usuario.NombreUsuario.Trim();
                    cmd.Parameters.Add("@Clave", SqlDbType.NVarChar, 100).Value = usuario.Clave.Trim();
                    cmd.Parameters.Add("@Nombre", SqlDbType.NVarChar, 50).Value = usuario.Nombre.Trim();
                    cmd.Parameters.Add("@Apellido", SqlDbType.NVarChar, 50).Value = usuario.Apellido.Trim();
                    cmd.Parameters.Add("@Rol", SqlDbType.NVarChar, 20).Value = usuario.Rol.Trim();

                    conn.Open();
                    object result = cmd.ExecuteScalar();
                    if (result != null && int.TryParse(result.ToString(), out int newId) && newId > 0)
                    {
                        usuario.Id = newId;
                        return true;
                    }

                    return false; // No filas afectadas
                }
            }
            catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
            {
                // Violation of UNIQUE constraint on NombreUsuario
                throw new Exception("El nombre de usuario ya está en uso. Elija otro.", ex);
            }
            catch (Exception ex)
            {
                // Cualquier otro error
                throw new Exception("Error al registrar usuario: " + ex.Message, ex);
            }
        }


        public Usuario Login(string nombreUsuario, string clave)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                string query = @"SELECT * FROM Usuarios 
                             WHERE NombreUsuario = @NombreUsuario AND Clave = @Clave";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
                    cmd.Parameters.AddWithValue("@Clave", clave); // Comparar encriptado si aplica

                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Usuario
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                NombreUsuario = reader["NombreUsuario"].ToString(),
                                Clave = reader["Clave"].ToString(),
                                Nombre = reader["Nombre"].ToString(),
                                Apellido = reader["Apellido"].ToString(),
                                Rol = reader["Rol"].ToString()
                            };
                        }
                        else
                        {
                            return null; // Login fallido
                        }


                    }

                }

            }

        }
    }
}

    

















