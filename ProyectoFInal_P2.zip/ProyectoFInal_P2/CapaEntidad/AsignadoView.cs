﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class AsignadoView
    {
        public string Nombre_Conductor { get; set; }
        public string Apellido_Conductor { get; set; }
        public string Cedula { get; set; }
        public string Autobus_Marca { get; set; }
        public string Autobus_Modelo { get; set; }
        public string Autobus_Placa { get; set; }
        public int Autobus_Año { get; set; }
        public string Ruta { get; set; }

    }
}
