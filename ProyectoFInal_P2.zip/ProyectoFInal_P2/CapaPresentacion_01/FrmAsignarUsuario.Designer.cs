﻿namespace CapaPresentacion_01
{
    partial class FrmAsignarUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DgvChoferes = new DataGridView();
            dgvAutobuses = new DataGridView();
            dgvRutas = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label = new Label();
            label5 = new Label();
            txtChoferSeleccionado = new TextBox();
            txtAutubesSeleccionar = new TextBox();
            btnAgregar = new Button();
            txtRutaSeleccionar = new TextBox();
            label4 = new Label();
            Salir = new Button();
            BtnRegistro = new Button();
            ((System.ComponentModel.ISupportInitialize)DgvChoferes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvAutobuses).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvRutas).BeginInit();
            SuspendLayout();
            // 
            // DgvChoferes
            // 
            DgvChoferes.AllowUserToAddRows = false;
            DgvChoferes.AllowUserToDeleteRows = false;
            DgvChoferes.BackgroundColor = Color.White;
            DgvChoferes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvChoferes.Location = new Point(21, 425);
            DgvChoferes.Margin = new Padding(4);
            DgvChoferes.Name = "DgvChoferes";
            DgvChoferes.ReadOnly = true;
            DgvChoferes.RowHeadersWidth = 51;
            DgvChoferes.Size = new Size(472, 285);
            DgvChoferes.TabIndex = 0;
            DgvChoferes.CellClick += DgvChoferes_CellClick;
            // 
            // dgvAutobuses
            // 
            dgvAutobuses.AllowUserToAddRows = false;
            dgvAutobuses.AllowUserToDeleteRows = false;
            dgvAutobuses.BackgroundColor = Color.White;
            dgvAutobuses.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAutobuses.Location = new Point(515, 425);
            dgvAutobuses.Margin = new Padding(4);
            dgvAutobuses.Name = "dgvAutobuses";
            dgvAutobuses.ReadOnly = true;
            dgvAutobuses.RowHeadersWidth = 51;
            dgvAutobuses.Size = new Size(472, 285);
            dgvAutobuses.TabIndex = 1;
            dgvAutobuses.CellClick += dgvAutobuses_CellClick;
            // 
            // dgvRutas
            // 
            dgvRutas.AllowUserToAddRows = false;
            dgvRutas.AllowUserToDeleteRows = false;
            dgvRutas.BackgroundColor = Color.White;
            dgvRutas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRutas.Location = new Point(1010, 425);
            dgvRutas.Margin = new Padding(4);
            dgvRutas.Name = "dgvRutas";
            dgvRutas.ReadOnly = true;
            dgvRutas.RowHeadersWidth = 51;
            dgvRutas.Size = new Size(458, 282);
            dgvRutas.TabIndex = 2;
            dgvRutas.CellClick += dgvRutas_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(21, 368);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(104, 30);
            label1.TabIndex = 3;
            label1.Text = "Choferes";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(515, 368);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(122, 30);
            label2.TabIndex = 4;
            label2.Text = "Autobuses";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(1010, 368);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(71, 30);
            label3.TabIndex = 5;
            label3.Text = "Rutas";
            // 
            // label
            // 
            label.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label.Location = new Point(13, 106);
            label.Margin = new Padding(4, 0, 4, 0);
            label.Name = "label";
            label.Size = new Size(309, 39);
            label.TabIndex = 6;
            label.Text = "Chofer Seleccionado:";
            label.Click += label_Click;
            // 
            // label5
            // 
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(545, 111);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(283, 48);
            label5.TabIndex = 7;
            label5.Text = "Autobus Seleccionado:";
            // 
            // txtChoferSeleccionado
            // 
            txtChoferSeleccionado.Location = new Point(316, 113);
            txtChoferSeleccionado.Margin = new Padding(4);
            txtChoferSeleccionado.Name = "txtChoferSeleccionado";
            txtChoferSeleccionado.Size = new Size(229, 31);
            txtChoferSeleccionado.TabIndex = 8;
            // 
            // txtAutubesSeleccionar
            // 
            txtAutubesSeleccionar.Location = new Point(813, 111);
            txtAutubesSeleccionar.Margin = new Padding(4);
            txtAutubesSeleccionar.Name = "txtAutubesSeleccionar";
            txtAutubesSeleccionar.Size = new Size(258, 31);
            txtAutubesSeleccionar.TabIndex = 9;
            // 
            // btnAgregar
            // 
            btnAgregar.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAgregar.Location = new Point(671, 221);
            btnAgregar.Margin = new Padding(4);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(199, 55);
            btnAgregar.TabIndex = 10;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // txtRutaSeleccionar
            // 
            txtRutaSeleccionar.Location = new Point(1281, 115);
            txtRutaSeleccionar.Margin = new Padding(4);
            txtRutaSeleccionar.Name = "txtRutaSeleccionar";
            txtRutaSeleccionar.Size = new Size(208, 31);
            txtRutaSeleccionar.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(1079, 115);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(208, 30);
            label4.TabIndex = 11;
            label4.Text = "Ruta Seleccionado:";
            // 
            // Salir
            // 
            Salir.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Salir.Location = new Point(1290, 2);
            Salir.Margin = new Padding(4);
            Salir.Name = "Salir";
            Salir.Size = new Size(199, 55);
            Salir.TabIndex = 13;
            Salir.Text = "Salir";
            Salir.UseVisualStyleBackColor = true;
            Salir.Click += Salir_Click;
            // 
            // BtnRegistro
            // 
            BtnRegistro.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnRegistro.Location = new Point(2, 2);
            BtnRegistro.Margin = new Padding(4);
            BtnRegistro.Name = "BtnRegistro";
            BtnRegistro.Size = new Size(199, 55);
            BtnRegistro.TabIndex = 14;
            BtnRegistro.Text = "Volver Al login";
            BtnRegistro.UseVisualStyleBackColor = true;
            BtnRegistro.Click += BtnRegistro_Click;
            // 
            // FrmAsignarUsuario
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSalmon;
            ClientSize = new Size(1491, 810);
            Controls.Add(BtnRegistro);
            Controls.Add(Salir);
            Controls.Add(txtRutaSeleccionar);
            Controls.Add(label4);
            Controls.Add(btnAgregar);
            Controls.Add(txtAutubesSeleccionar);
            Controls.Add(txtChoferSeleccionado);
            Controls.Add(label5);
            Controls.Add(label);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvRutas);
            Controls.Add(dgvAutobuses);
            Controls.Add(DgvChoferes);
            Margin = new Padding(4);
            Name = "FrmAsignarUsuario";
            Text = "FrmAsignarUsuario";
            Load += FrmAsignarUsuario_Load;
            ((System.ComponentModel.ISupportInitialize)DgvChoferes).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvAutobuses).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvRutas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView DgvChoferes;
        private DataGridView dgvAutobuses;
        private DataGridView dgvRutas;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label;
        private Label label5;
        private TextBox txtChoferSeleccionado;
        private TextBox txtAutubesSeleccionar;
        private Button btnAgregar;
        private TextBox txtRutaSeleccionar;
        private Label label4;
        private Button Salir;
        private Button BtnRegistro;
    }
}