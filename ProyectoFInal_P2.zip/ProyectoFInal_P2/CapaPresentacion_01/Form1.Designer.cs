﻿namespace CapaPresentacion_01
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            dgvRutas = new DataGridView();
            dgvAutobuses = new DataGridView();
            dgvConductores = new DataGridView();
            groupBox1 = new GroupBox();
            groupBox4 = new GroupBox();
            btnRegistrarAutobus = new Button();
            color = new TextBox();
            label11 = new Label();
            placa = new TextBox();
            año = new TextBox();
            label7 = new Label();
            label8 = new Label();
            modelo = new TextBox();
            label9 = new Label();
            marca = new TextBox();
            label10 = new Label();
            groupBox3 = new GroupBox();
            btnRegistrarRuta = new Button();
            ruta = new TextBox();
            label6 = new Label();
            groupBox2 = new GroupBox();
            btnRegistrarConductor = new Button();
            cedula = new TextBox();
            label5 = new Label();
            fechaN = new DateTimePicker();
            label4 = new Label();
            apellido = new TextBox();
            label3 = new Label();
            nombre = new TextBox();
            label2 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            menuStrip1 = new MenuStrip();
            opcionesToolStripMenuItem = new ToolStripMenuItem();
            asignarConductoresToolStripMenuItem = new ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)dgvRutas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvAutobuses).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvConductores).BeginInit();
            groupBox1.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(1072, 523);
            label12.Name = "label12";
            label12.Size = new Size(153, 22);
            label12.TabIndex = 28;
            label12.Text = "Rutas registradas:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.Location = new Point(555, 523);
            label13.Name = "label13";
            label13.Size = new Size(187, 22);
            label13.TabIndex = 27;
            label13.Text = "Autobuses registrados:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.Location = new Point(18, 523);
            label14.Name = "label14";
            label14.Size = new Size(204, 22);
            label14.TabIndex = 26;
            label14.Text = "Conductores registrados:";
            // 
            // dgvRutas
            // 
            dgvRutas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvRutas.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            dgvRutas.BackgroundColor = SystemColors.Control;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvRutas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvRutas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvRutas.DefaultCellStyle = dataGridViewCellStyle2;
            dgvRutas.Location = new Point(1076, 557);
            dgvRutas.Name = "dgvRutas";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dgvRutas.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dgvRutas.RowHeadersWidth = 51;
            dgvRutas.RowTemplate.Height = 24;
            dgvRutas.Size = new Size(411, 141);
            dgvRutas.TabIndex = 25;
            // 
            // dgvAutobuses
            // 
            dgvAutobuses.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAutobuses.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            dgvAutobuses.BackgroundColor = SystemColors.Control;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dgvAutobuses.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dgvAutobuses.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = SystemColors.Window;
            dataGridViewCellStyle5.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dgvAutobuses.DefaultCellStyle = dataGridViewCellStyle5;
            dgvAutobuses.Location = new Point(559, 557);
            dgvAutobuses.Name = "dgvAutobuses";
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = SystemColors.Control;
            dataGridViewCellStyle6.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dgvAutobuses.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dgvAutobuses.RowHeadersWidth = 51;
            dgvAutobuses.RowTemplate.Height = 24;
            dgvAutobuses.Size = new Size(511, 141);
            dgvAutobuses.TabIndex = 24;
            // 
            // dgvConductores
            // 
            dgvConductores.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvConductores.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            dgvConductores.BackgroundColor = SystemColors.Control;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = SystemColors.Control;
            dataGridViewCellStyle7.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle7.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.True;
            dgvConductores.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            dgvConductores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = SystemColors.Window;
            dataGridViewCellStyle8.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle8.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            dgvConductores.DefaultCellStyle = dataGridViewCellStyle8;
            dgvConductores.Location = new Point(18, 557);
            dgvConductores.Name = "dgvConductores";
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = SystemColors.Control;
            dataGridViewCellStyle9.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle9.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.True;
            dgvConductores.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            dgvConductores.RowHeadersWidth = 51;
            dgvConductores.RowTemplate.Height = 24;
            dgvConductores.Size = new Size(535, 141);
            dgvConductores.TabIndex = 23;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(groupBox4);
            groupBox1.Controls.Add(groupBox3);
            groupBox1.Controls.Add(groupBox2);
            groupBox1.FlatStyle = FlatStyle.System;
            groupBox1.Font = new Font("Modern No. 20", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(18, 138);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1469, 368);
            groupBox1.TabIndex = 22;
            groupBox1.TabStop = false;
            groupBox1.Text = "Registro de conductores, autobuses y rutas";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(btnRegistrarAutobus);
            groupBox4.Controls.Add(color);
            groupBox4.Controls.Add(label11);
            groupBox4.Controls.Add(placa);
            groupBox4.Controls.Add(año);
            groupBox4.Controls.Add(label7);
            groupBox4.Controls.Add(label8);
            groupBox4.Controls.Add(modelo);
            groupBox4.Controls.Add(label9);
            groupBox4.Controls.Add(marca);
            groupBox4.Controls.Add(label10);
            groupBox4.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox4.Location = new Point(17, 191);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(933, 158);
            groupBox4.TabIndex = 2;
            groupBox4.TabStop = false;
            groupBox4.Text = "Registrar Autobus:";
            // 
            // btnRegistrarAutobus
            // 
            btnRegistrarAutobus.BackColor = SystemColors.Control;
            btnRegistrarAutobus.FlatStyle = FlatStyle.Popup;
            btnRegistrarAutobus.Font = new Font("Modern No. 20", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegistrarAutobus.Location = new Point(407, 103);
            btnRegistrarAutobus.Name = "btnRegistrarAutobus";
            btnRegistrarAutobus.Size = new Size(111, 38);
            btnRegistrarAutobus.TabIndex = 11;
            btnRegistrarAutobus.Text = "Registrar";
            btnRegistrarAutobus.UseVisualStyleBackColor = false;
            btnRegistrarAutobus.Click += btnRegistrarAutobus_Click;
            // 
            // color
            // 
            color.BackColor = SystemColors.Control;
            color.BorderStyle = BorderStyle.FixedSingle;
            color.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            color.Location = new Point(788, 53);
            color.Name = "color";
            color.Size = new Size(132, 27);
            color.TabIndex = 10;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(727, 53);
            label11.Name = "label11";
            label11.Size = new Size(58, 22);
            label11.TabIndex = 9;
            label11.Text = "Color:";
            // 
            // placa
            // 
            placa.BackColor = SystemColors.Control;
            placa.BorderStyle = BorderStyle.FixedSingle;
            placa.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            placa.Location = new Point(474, 53);
            placa.Name = "placa";
            placa.Size = new Size(119, 27);
            placa.TabIndex = 8;
            // 
            // año
            // 
            año.BackColor = SystemColors.Control;
            año.BorderStyle = BorderStyle.FixedSingle;
            año.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            año.Location = new Point(647, 54);
            año.Name = "año";
            año.Size = new Size(79, 27);
            año.TabIndex = 7;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(599, 53);
            label7.Name = "label7";
            label7.Size = new Size(49, 22);
            label7.TabIndex = 6;
            label7.Text = "Año:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(413, 53);
            label8.Name = "label8";
            label8.Size = new Size(60, 22);
            label8.TabIndex = 4;
            label8.Text = "Placa:";
            // 
            // modelo
            // 
            modelo.BackColor = SystemColors.Control;
            modelo.BorderStyle = BorderStyle.FixedSingle;
            modelo.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            modelo.Location = new Point(289, 53);
            modelo.Name = "modelo";
            modelo.Size = new Size(124, 27);
            modelo.TabIndex = 3;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(216, 53);
            label9.Name = "label9";
            label9.Size = new Size(74, 22);
            label9.TabIndex = 2;
            label9.Text = "Modelo:";
            // 
            // marca
            // 
            marca.BackColor = SystemColors.Control;
            marca.BorderStyle = BorderStyle.FixedSingle;
            marca.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            marca.Location = new Point(80, 53);
            marca.Name = "marca";
            marca.Size = new Size(130, 27);
            marca.TabIndex = 1;
            // 
            // label10
            // 
            label10.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(16, 53);
            label10.Margin = new Padding(0);
            label10.Name = "label10";
            label10.Size = new Size(71, 22);
            label10.TabIndex = 0;
            label10.Text = "Marca:";
            label10.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btnRegistrarRuta);
            groupBox3.Controls.Add(ruta);
            groupBox3.Controls.Add(label6);
            groupBox3.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox3.Location = new Point(956, 191);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(491, 158);
            groupBox3.TabIndex = 1;
            groupBox3.TabStop = false;
            groupBox3.Text = "Registrar ruta:";
            // 
            // btnRegistrarRuta
            // 
            btnRegistrarRuta.BackColor = SystemColors.Control;
            btnRegistrarRuta.FlatStyle = FlatStyle.Popup;
            btnRegistrarRuta.Font = new Font("Modern No. 20", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegistrarRuta.Location = new Point(187, 103);
            btnRegistrarRuta.Name = "btnRegistrarRuta";
            btnRegistrarRuta.Size = new Size(114, 38);
            btnRegistrarRuta.TabIndex = 5;
            btnRegistrarRuta.Text = "Registrar";
            btnRegistrarRuta.UseVisualStyleBackColor = false;
            btnRegistrarRuta.Click += btnRegistrarRuta_Click;
            // 
            // ruta
            // 
            ruta.BackColor = SystemColors.Control;
            ruta.BorderStyle = BorderStyle.FixedSingle;
            ruta.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ruta.Location = new Point(171, 53);
            ruta.Name = "ruta";
            ruta.Size = new Size(299, 27);
            ruta.TabIndex = 4;
            // 
            // label6
            // 
            label6.Font = new Font("Modern No. 20", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(18, 53);
            label6.Name = "label6";
            label6.Size = new Size(160, 22);
            label6.TabIndex = 0;
            label6.Text = "Nombre de ruta:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnRegistrarConductor);
            groupBox2.Controls.Add(cedula);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(fechaN);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(apellido);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(nombre);
            groupBox2.Controls.Add(label2);
            groupBox2.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(17, 31);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(1430, 142);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            groupBox2.Text = "Registrar conductor:";
            // 
            // btnRegistrarConductor
            // 
            btnRegistrarConductor.BackColor = SystemColors.Control;
            btnRegistrarConductor.FlatStyle = FlatStyle.Popup;
            btnRegistrarConductor.Font = new Font("Modern No. 20", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegistrarConductor.Location = new Point(672, 100);
            btnRegistrarConductor.Name = "btnRegistrarConductor";
            btnRegistrarConductor.Size = new Size(113, 36);
            btnRegistrarConductor.TabIndex = 8;
            btnRegistrarConductor.Text = "Registrar";
            btnRegistrarConductor.UseVisualStyleBackColor = false;
            btnRegistrarConductor.Click += btnRegistrarConductor_Click;
            // 
            // cedula
            // 
            cedula.BackColor = SystemColors.Control;
            cedula.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cedula.Location = new Point(1137, 54);
            cedula.Name = "cedula";
            cedula.Size = new Size(232, 27);
            cedula.TabIndex = 7;
            // 
            // label5
            // 
            label5.Font = new Font("Modern No. 20", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(1066, 54);
            label5.Name = "label5";
            label5.Size = new Size(84, 22);
            label5.TabIndex = 6;
            label5.Text = "Cedula:";
            // 
            // fechaN
            // 
            fechaN.CalendarMonthBackground = SystemColors.Control;
            fechaN.CustomFormat = "dd/MM/yyyy";
            fechaN.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            fechaN.Format = DateTimePickerFormat.Short;
            fechaN.Location = new Point(896, 54);
            fechaN.Margin = new Padding(0);
            fechaN.Name = "fechaN";
            fechaN.Size = new Size(148, 27);
            fechaN.TabIndex = 5;
            // 
            // label4
            // 
            label4.Font = new Font("Modern No. 20", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(701, 53);
            label4.Name = "label4";
            label4.Size = new Size(219, 22);
            label4.TabIndex = 4;
            label4.Text = "Fecha de nacimiento:";
            // 
            // apellido
            // 
            apellido.BackColor = SystemColors.Control;
            apellido.BorderStyle = BorderStyle.FixedSingle;
            apellido.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            apellido.Location = new Point(443, 53);
            apellido.Name = "apellido";
            apellido.Size = new Size(252, 27);
            apellido.TabIndex = 3;
            // 
            // label3
            // 
            label3.Font = new Font("Modern No. 20", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(354, 54);
            label3.Name = "label3";
            label3.Size = new Size(106, 22);
            label3.TabIndex = 2;
            label3.Text = "Apellido:";
            // 
            // nombre
            // 
            nombre.BackColor = SystemColors.Control;
            nombre.BorderStyle = BorderStyle.FixedSingle;
            nombre.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            nombre.ForeColor = SystemColors.WindowText;
            nombre.Location = new Point(120, 54);
            nombre.Name = "nombre";
            nombre.Size = new Size(219, 27);
            nombre.TabIndex = 1;
            // 
            // label2
            // 
            label2.Font = new Font("Modern No. 20", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(42, 53);
            label2.Name = "label2";
            label2.Size = new Size(89, 22);
            label2.TabIndex = 0;
            label2.Text = "Nombre:";
            // 
            // label1
            // 
            label1.Font = new Font("Modern No. 20", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(514, 62);
            label1.Name = "label1";
            label1.Size = new Size(791, 36);
            label1.TabIndex = 21;
            label1.Text = "Sistema de Control Autobuses.";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImageLayout = ImageLayout.Center;
            pictureBox1.Location = new Point(295, 19);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(191, 113);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 20;
            pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.Transparent;
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { opcionesToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1505, 29);
            menuStrip1.TabIndex = 29;
            menuStrip1.Text = "menuStrip1";
            // 
            // opcionesToolStripMenuItem
            // 
            opcionesToolStripMenuItem.BackColor = Color.Transparent;
            opcionesToolStripMenuItem.DisplayStyle = ToolStripItemDisplayStyle.Text;
            opcionesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { asignarConductoresToolStripMenuItem });
            opcionesToolStripMenuItem.Font = new Font("Modern No. 20", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            opcionesToolStripMenuItem.ForeColor = SystemColors.ActiveCaptionText;
            opcionesToolStripMenuItem.Name = "opcionesToolStripMenuItem";
            opcionesToolStripMenuItem.Size = new Size(81, 25);
            opcionesToolStripMenuItem.Text = "Asignar";
            // 
            // asignarConductoresToolStripMenuItem
            // 
            asignarConductoresToolStripMenuItem.Name = "asignarConductoresToolStripMenuItem";
            asignarConductoresToolStripMenuItem.Size = new Size(239, 26);
            asignarConductoresToolStripMenuItem.Text = "Asignar conductores";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSalmon;
            ClientSize = new Size(1505, 717);
            Controls.Add(menuStrip1);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(dgvRutas);
            Controls.Add(dgvAutobuses);
            Controls.Add(dgvConductores);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvRutas).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvAutobuses).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvConductores).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label12;
        private Label label13;
        private Label label14;
        private DataGridView dgvRutas;
        private DataGridView dgvAutobuses;
        private DataGridView dgvConductores;
        private GroupBox groupBox1;
        private GroupBox groupBox4;
        private Button btnRegistrarAutobus;
        private TextBox color;
        private Label label11;
        private TextBox placa;
        private TextBox año;
        private Label label7;
        private Label label8;
        private TextBox modelo;
        private Label label9;
        private TextBox marca;
        private Label label10;
        private GroupBox groupBox3;
        private Button btnRegistrarRuta;
        private TextBox ruta;
        private Label label6;
        private GroupBox groupBox2;
        private Button btnRegistrarConductor;
        private TextBox cedula;
        private Label label5;
        private DateTimePicker fechaN;
        private Label label4;
        private TextBox apellido;
        private Label label3;
        private TextBox nombre;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem opcionesToolStripMenuItem;
        private ToolStripMenuItem asignarConductoresToolStripMenuItem;
    }
}
