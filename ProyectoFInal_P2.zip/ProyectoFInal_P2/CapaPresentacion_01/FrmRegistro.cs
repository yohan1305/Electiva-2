﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaEntidad.Usuario;
using CapaNegocio;

namespace CapaPresentacion_01
{
    public partial class FrmRegistro : Form
    {
        private readonly UsuarioService usuarioService = new UsuarioService();

        public FrmRegistro()
        {
            InitializeComponent();
        }

        private void FrmRegistro_Load(object sender, EventArgs e)
        {
            cboRol.Items.Add("Administrador");
            cboRol.Items.Add("Usuario");
            cboRol.SelectedIndex = 0;
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
          
            if (string.IsNullOrWhiteSpace(txtUsuarioRegistro.Text) ||
                string.IsNullOrWhiteSpace(txtContraseña.Text) ||
                string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellido.Text) ||
                cboRol.SelectedItem == null)
            {
                MessageBox.Show("Por favor, complete todos los campos antes de registrar.");
                return;
            }

           
            var usuario = new Usuario
            {
                NombreUsuario = txtUsuarioRegistro.Text.Trim(),
                Clave = txtContraseña.Text.Trim(), // Sin encriptar
                Nombre = txtNombre.Text.Trim(),
                Apellido = txtApellido.Text.Trim(),
                Rol = cboRol.SelectedItem.ToString()
            };

            try
            {
                bool registrado = usuarioService.Registrar(usuario);

                if (registrado)
                {
                    MessageBox.Show("Usuario registrado correctamente.");
                    LimpiarFormulario(); 
                }
                else
                {
                    MessageBox.Show("No se pudo registrar el usuario. Verifique los datos o intente nuevamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inesperado: " + ex.Message);
            }
        }

        
        private void LimpiarFormulario()
        {
            txtUsuarioRegistro.Clear();
            txtContraseña.Clear();
            txtNombre.Clear();
            txtApellido.Clear();
            cboRol.SelectedIndex = -1;
        }



    }
}