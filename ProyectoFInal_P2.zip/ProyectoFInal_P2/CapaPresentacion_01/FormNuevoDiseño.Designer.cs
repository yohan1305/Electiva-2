﻿namespace CapaPresentacion_01
{
    partial class FormNuevoDiseño
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormNuevoDiseño));
            panel1 = new Panel();
            btncerrar = new Button();
            pictureBox1 = new PictureBox();
            txtusuario = new TextBox();
            panel2 = new Panel();
            txtClave = new TextBox();
            panel3 = new Panel();
            btnEntrar = new Button();
            btnRegistrarme = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSalmon;
            panel1.Controls.Add(btncerrar);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 4, 4, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(986, 60);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // btncerrar
            // 
            btncerrar.BackgroundImage = (Image)resources.GetObject("btncerrar.BackgroundImage");
            btncerrar.BackgroundImageLayout = ImageLayout.Stretch;
            btncerrar.Location = new Point(869, 4);
            btncerrar.Margin = new Padding(4, 4, 4, 4);
            btncerrar.Name = "btncerrar";
            btncerrar.Size = new Size(91, 52);
            btncerrar.TabIndex = 0;
            btncerrar.UseVisualStyleBackColor = true;
            btncerrar.Click += btncerrar_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Snow;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(380, 84);
            pictureBox1.Margin = new Padding(4, 4, 4, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(156, 90);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // txtusuario
            // 
            txtusuario.BorderStyle = BorderStyle.None;
            txtusuario.Font = new Font("Yu Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtusuario.Location = new Point(252, 219);
            txtusuario.Margin = new Padding(4, 4, 4, 4);
            txtusuario.Name = "txtusuario";
            txtusuario.Size = new Size(405, 33);
            txtusuario.TabIndex = 2;
            txtusuario.TextAlign = HorizontalAlignment.Center;
            txtusuario.TextChanged += txtusuario_TextChanged;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Location = new Point(252, 270);
            panel2.Margin = new Padding(4, 4, 4, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(405, 12);
            panel2.TabIndex = 3;
            // 
            // txtClave
            // 
            txtClave.BorderStyle = BorderStyle.None;
            txtClave.Font = new Font("Yu Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtClave.Location = new Point(252, 309);
            txtClave.Margin = new Padding(4, 4, 4, 4);
            txtClave.Name = "txtClave";
            txtClave.Size = new Size(405, 33);
            txtClave.TabIndex = 4;
            txtClave.TextAlign = HorizontalAlignment.Center;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gray;
            panel3.Location = new Point(252, 362);
            panel3.Margin = new Padding(4, 4, 4, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(408, 12);
            panel3.TabIndex = 5;
            // 
            // btnEntrar
            // 
            btnEntrar.BackColor = Color.DarkSalmon;
            btnEntrar.Font = new Font("Microsoft Sans Serif", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEntrar.Location = new Point(366, 401);
            btnEntrar.Margin = new Padding(4, 4, 4, 4);
            btnEntrar.Name = "btnEntrar";
            btnEntrar.Size = new Size(170, 58);
            btnEntrar.TabIndex = 7;
            btnEntrar.Text = "Entrar";
            btnEntrar.UseVisualStyleBackColor = false;
            btnEntrar.Click += btnEntrar_Click;
            // 
            // btnRegistrarme
            // 
            btnRegistrarme.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegistrarme.ForeColor = Color.Black;
            btnRegistrarme.Location = new Point(366, 596);
            btnRegistrarme.Margin = new Padding(4, 4, 4, 4);
            btnRegistrarme.Name = "btnRegistrarme";
            btnRegistrarme.Size = new Size(170, 55);
            btnRegistrarme.TabIndex = 9;
            btnRegistrarme.Text = "Registrarme";
            btnRegistrarme.UseVisualStyleBackColor = true;
            btnRegistrarme.Click += btnRegistrarme_Click;
            // 
            // FormNuevoDiseño
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            BackColor = Color.SeaShell;
            ClientSize = new Size(986, 666);
            Controls.Add(btnRegistrarme);
            Controls.Add(btnEntrar);
            Controls.Add(panel3);
            Controls.Add(txtClave);
            Controls.Add(panel2);
            Controls.Add(txtusuario);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 4, 4, 4);
            Name = "FormNuevoDiseño";
            Opacity = 0.9D;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Formlogin";
            Load += FormNuevoDiseño_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button btncerrar;
        private PictureBox pictureBox1;
        private TextBox txtusuario;
        private Panel panel2;
        private TextBox txtClave;
        private Panel panel3;
        private CheckBox checkBox1;
        private Button btnEntrar;
        private Label label1;
        private Button btnRegistrarme;
    }
}