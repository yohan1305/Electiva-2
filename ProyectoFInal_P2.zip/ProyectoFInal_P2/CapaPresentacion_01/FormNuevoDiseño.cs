﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace CapaPresentacion_01
{
    public partial class FormNuevoDiseño : Form
    {

        private readonly UsuarioService usuarioService = new UsuarioService();

        public FormNuevoDiseño()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void FormNuevoDiseño_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string nombreUsuario = txtusuario.Text.Trim();
            string clave = txtClave.Text.Trim();

            if (string.IsNullOrWhiteSpace(nombreUsuario) || string.IsNullOrWhiteSpace(clave))
            {
                MessageBox.Show("⚠️ Por favor, ingrese usuario y clave.");
                return;
            }

            try
            {
                var usuario = usuarioService.Login(nombreUsuario, clave);

                if (usuario != null)
                {
                    MessageBox.Show($"Bienvenido, {usuario.Nombre} {usuario.Apellido}.");

                    if (usuario.Rol == "Administrador")
                    {
                        Form1 frmAdmin = new Form1();
                        frmAdmin.Show();
                    }
                    else if (usuario.Rol == "Usuario")
                    {
                        FrmAsignarUsuario frmCliente = new FrmAsignarUsuario(usuario);
                        frmCliente.Show();
                    }
                    else
                    {
                        MessageBox.Show("Rol no reconocido. Contacte al administrador.");
                        return;
                    }

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Usuario o clave incorrectos.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar iniciar sesión: " + ex.Message);
            }
        }

        private void txtusuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRegistrarme_Click(object sender, EventArgs e)
        {
    
            FrmRegistro formularioRegistro = new FrmRegistro();

            
            formularioRegistro.Show();

            
            this.Hide();
        }

        private void btncerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

