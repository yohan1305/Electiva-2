using System;
using System.Data;
using System.Windows.Forms;
using CapaEntidad;
using CapaNegocio;



namespace CapaPresentacion_01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private readonly ConductorService conductorService = new ConductorService();
        private readonly AutobusService autobusService = new AutobusService();
        private readonly RutaService rutaService = new RutaService();

        private void CargarConductores()
        {
            dgvConductores.DataSource = conductorService.Listar();
            dgvConductores.Columns["Estado"].Visible = false;
        }

        private void CargarAutobuses()
        {
            dgvAutobuses.DataSource = autobusService.Listar();
            dgvAutobuses.Columns["Estado"].Visible = false;
        }

        private void CargarRutas()
        {
            dgvRutas.DataSource = rutaService.Listar();
            dgvRutas.Columns["Estado"].Visible = false;
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnRegistrarConductor_Click(object sender, EventArgs e)
        {
            string cedulaInput = cedula.Text.Trim();
            string nombreInput = nombre.Text.Trim();
            string apellidoInput = apellido.Text.Trim();
            DateTime fechaNacimiento = fechaN.Value;

            
            if (string.IsNullOrWhiteSpace(cedulaInput) ||
                string.IsNullOrWhiteSpace(nombreInput) ||
                string.IsNullOrWhiteSpace(apellidoInput))
            {
                MessageBox.Show("Todos los campos son obligatorios.");
                return;
            }

           
            if (conductorService.ExisteCedula(cedulaInput))
            {
                MessageBox.Show("Ya existe un conductor con esa c�dula.");
                return;
            }

           
            var conductor = new Conductor
            {
                Cedula = cedulaInput,
                Nombre = nombreInput,
                Apellido = apellidoInput,
                FechaN = fechaNacimiento,
                Estado = false 
            };

            
            conductorService.Registrar(conductor);
            MessageBox.Show("Conductor registrado correctamente.");
            CargarConductores();

          
            cedula.Clear();
            nombre.Clear();
            apellido.Clear();
            fechaN.Value = DateTime.Today;
        }

        private void btnRegistrarAutobus_Click(object sender, EventArgs e)
        {
            var autobus = new Autobus
            {
                Marca = marca.Text.Trim(),
                Modelo = modelo.Text.Trim(),
                A�o = int.Parse(a�o.Text),
                Placa = placa.Text.Trim(),
                Color = color.Text.Trim()
            };

            autobusService.Registrar(autobus);
            MessageBox.Show("Autob�s registrado correctamente.");
            CargarAutobuses();

        }

        private void btnRegistrarRuta_Click(object sender, EventArgs e)
        {
            var nuevaRuta = new Ruta
            {
                RutaNombre = ruta.Text.Trim()
            };

            rutaService.Registrar(nuevaRuta);
            MessageBox.Show("Ruta registrada correctamente.");
            CargarRutas();
        }

       
        private void label5_Click(object sender, EventArgs e) { }
        private void asignarConductoresToolStripMenuItem_Click(object sender, EventArgs e) { }
        private void opcionesToolStripMenuItem_Click(object sender, EventArgs e) { }
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e) { }
        private void nombre_TextChanged(object sender, EventArgs e) { }
        private void apellido_TextChanged(object sender, EventArgs e) { }

    }
}
