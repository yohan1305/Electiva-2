﻿using CapaEntidad;
using CapaEntidad.Usuario;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion_01
{
    public partial class FrmAsignarUsuario : Form
    {

        private readonly ConductorService conductorService = new ConductorService();
        private readonly AutobusService autobusService = new AutobusService();
        private readonly RutaService rutaService = new RutaService();
        private readonly AsignacionService asignacionService = new AsignacionService();
        private Usuario usuarioLogueado;


        public FrmAsignarUsuario(Usuario usuario)
        {
            InitializeComponent();
            usuarioLogueado = usuario;

        }

        private void FrmAsignarUsuario_Load(object sender, EventArgs e)
        {
            DgvChoferes.DataSource = conductorService.Listar().Where(c => !c.Estado).ToList();
            dgvAutobuses.DataSource = autobusService.Listar().Where(a => !a.Estado).ToList();
            dgvRutas.DataSource = rutaService.Listar().Where(r => !r.Estado).ToList();
        }

        private void DgvChoferes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var fila = DgvChoferes.Rows[e.RowIndex];
                txtChoferSeleccionado.Text = fila.Cells["Nombre"].Value.ToString() + " " + fila.Cells["Apellido"].Value.ToString();
                txtChoferSeleccionado.Tag = fila.Cells["ConductorID"].Value;
            }
        }

        private void dgvAutobuses_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var fila = dgvAutobuses.Rows[e.RowIndex];
                txtAutubesSeleccionar.Text = fila.Cells["Marca"].Value.ToString() + " " + fila.Cells["Modelo"].Value.ToString();
                txtAutubesSeleccionar.Tag = fila.Cells["AutobusID"].Value;
            }
        }

        private void dgvRutas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var fila = dgvRutas.Rows[e.RowIndex];
                txtRutaSeleccionar.Text = fila.Cells["RutaNombre"].Value.ToString();
                txtRutaSeleccionar.Tag = fila.Cells["RutaID"].Value;
            }
        }



        private void label_Click(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (txtChoferSeleccionado.Tag == null || txtAutubesSeleccionar.Tag == null || txtRutaSeleccionar.Tag == null)
            {
                MessageBox.Show("Debe seleccionar un chofer, un autobús y una ruta.");
                return;
            }

            var asignacion = new Asignacion
            {
                ConductorID = Convert.ToInt32(txtChoferSeleccionado.Tag),
                AutobusID = Convert.ToInt32(txtAutubesSeleccionar.Tag),
                RutaID = Convert.ToInt32(txtRutaSeleccionar.Tag),
                UsuarioID = usuarioLogueado.Id
            };

            try
            {
                asignacionService.Registrar(asignacion);

                // 🔒 Actualizar estados a "ocupado"
                conductorService.ActualizarEstado(asignacion.ConductorID, true);
                autobusService.ActualizarEstado(asignacion.AutobusID, true);
                rutaService.ActualizarEstado(asignacion.RutaID, true);

                MessageBox.Show("Asignación registrada correctamente.");
                FrmAsignarUsuario_Load(null, null);
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void LimpiarCampos()
        {
            txtChoferSeleccionado.Clear();
            txtAutubesSeleccionar.Clear();
            txtRutaSeleccionar.Clear();
            txtChoferSeleccionado.Tag = null;
            txtAutubesSeleccionar.Tag = null;
            txtRutaSeleccionar.Tag = null;
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnRegistro_Click(object sender, EventArgs e)
        {
            FormNuevoDiseño frmCliente = new FormNuevoDiseño();
            frmCliente.Show();
        }
    }
}

